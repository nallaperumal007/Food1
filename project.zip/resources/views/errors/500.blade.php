<!DOCTYPE html>
<html>

<head>
    <title>Error!</title>
</head>

<body>
    <center>
        <h1>Woops!</h1>

        <h2>Something went wrong :(</h2>

        <p><a href="{{ URL::to('/') }}">Click here to go back</a></p>
    </center>
</body>

</html>